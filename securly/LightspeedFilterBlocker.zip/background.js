chrome.webRequest.onBeforeRequest.addListener(
  function(details) {
    if (details.url.includes("lightspeedsystems.com/filter_agent")) {
      return { cancel: true };
    }
  },
  { urls: ["<all_urls>"] },
  ["blocking"]
);
