# Lightspeed Filter Blocker

An extension that blocks the Lightspeed Filter agent.

## How to Install

1. Download this code to your machine.

2. Open Google Chrome and go to `chrome://extensions`.

3. Enable Developer mode by toggling the switch in the top-right corner.

4. Click on "Load unpacked" button and select the "LightspeedFilterBlocker" folder.

5. The extension should now appear in your extensions list and be ready for use.

## How to Use

Once the extension is installed, it will automatically block any requests to the Lightspeed Filter agent.

## How to Test

To test the extension, visit a website that uses the Lightspeed Filter agent. The extension should block the request and prevent the agent from loading.

## How to Develop

1. Make changes to the extension files as needed.

2. To see the changes, go to `chrome://extensions` and click on the "Refresh" button for the Lightspeed Filter Blocker extension.

3. Test the changes by visiting a website that uses the Lightspeed Filter agent and ensure that the request is blocked.

## How to Distribute

To distribute the extension, you need to package it as a .crx file. This can be done through the Chrome Web Store developer dashboard. Refer to the [official Chrome extension distribution guide](https://developer.chrome.com/docs/extensions/mv3/hosting/) for more details.

## Next Steps

Here are some possible next steps to improve the extension:

- Add options to enable/disable the blocking of the Lightspeed Filter agent.
- Implement a whitelist feature to allow certain websites to bypass the blocking.
- Add a notification to inform the user when a request to the Lightspeed Filter agent is blocked.
